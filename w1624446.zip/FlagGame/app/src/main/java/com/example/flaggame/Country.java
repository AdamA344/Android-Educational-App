package com.example.flaggame;

import android.content.Context;
import android.graphics.Color;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.Random;

public class Country extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
//timer
    int count = 10;

    //defines drawable images in R class which contains Resource ID's (r.drawables)
    public final static int getResourceId(final String resName, final String resType, final Context ctx) {
        final int ResourceID =
                ctx.getResources().getIdentifier(resName, resType,
                        ctx.getApplicationInfo().packageName);

        return ResourceID;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country);

        //calls on ID
        final ImageView img = findViewById(R.id.countryImages);
        final Random rnd = new Random();
        //randomly picks one from array
        final String str = MainActivity.imageNames[rnd.nextInt(256)];

        //uses resource ID to get that random image from the drawable and display it
        img.setImageDrawable(
                getResources().getDrawable(getResourceId(str, "drawable", getApplicationContext()))
        );

        final Spinner spinner = findViewById(R.id.country_list);
        if (spinner != null) {
            spinner.setOnItemSelectedListener(this);
        }
        // Create ArrayAdapter using the string array and default spinner layout to the arrat list of country names
        ArrayAdapter < CharSequence > adapter = ArrayAdapter.createFromResource(this,
                R.array.Flag_list, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner.
        if (spinner != null) {
            spinner.setAdapter(adapter);
        }

        final Button btn_submit = findViewById(R.id.btn_submit);
        btn_submit.setOnClickListener(new View.OnClickListener() {
            //button onClickListener activates the rest of this code which validates the answer
            public void onClick(View View) {
                TextView tv = findViewById(R.id.hAnswer);
                TextView ans = findViewById(R.id.ans);
                if (btn_submit.getText().equals("submit")) {
                    String ca = MainActivity.flagNamePairs.get(str);
                    if (spinner.getSelectedItem().toString().equals(ca)) {
                        tv.setTextColor(Color.GREEN);
                        tv.setText("CORRECT");
                    } else {
                        tv.setTextColor(Color.RED);
                        tv.setText("INCORRECT");
                        ans.setTextColor(Color.BLUE);
                        ans.setText(" The correct answer is " + ca);
                    }
                    btn_submit.setText("Next");
                } else {
                    finish();
                    startActivity(getIntent());
                }

            }

        });

        //if the switch was active this code will run where the timer will be added counting down from 10
        if (MainActivity.time == true) {

            final TextView countDown = findViewById(R.id.countDown);
            new CountDownTimer(10_000, 1_000) {
                String ca = MainActivity.flagNamePairs.get(str);
                TextView tv = findViewById(R.id.hAnswer);
                TextView ans = findViewById(R.id.ans);
                @Override
                public void onTick(long l) {
                    countDown.setText(String.valueOf(count));
                    count--;
                }
                //end of timer simulates entering the wrong answer
                @Override
                public void onFinish() {
                    countDown.setText(String.valueOf(0));
                    tv.setTextColor(Color.RED);
                    tv.setText("INCORRECT");
                    ans.setTextColor(Color.BLUE);
                    ans.setText(" The correct answer is " + ca);
                    btn_submit.setText("Next");
                }
            }.start();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}



