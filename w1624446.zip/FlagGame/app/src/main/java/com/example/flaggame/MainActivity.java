package com.example.flaggame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
// create static methods to be called upon in the other activities
    static String[] imageNames = getImageNames();
    static String[] countryNames;
    static HashMap < String, String > flagNamePairs;
    static boolean time = false;

    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //call on Array list in Strings.xml
        countryNames = getResources().getStringArray(R.array.Flag_list);
        flagNamePairs = createFlagNamePairs();

        //sets timer with a true/false statement to be applied to the other games with a a static method
        Switch timer = findViewById(R.id.start_timer);
        timer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (time) {
                    time = false;
                } else {
                    time = true;
                }
            }
        });

    }
    //loads up new activity
    public void guessTheCountry(View view) {
        Log.d(LOG_TAG, "Guess the country selected");
        Intent intent = new Intent(this, Country.class);
        startActivity(intent);
    }
    //loads up new activity
    public void guessHints(View view) {
        Log.d(LOG_TAG, "Guess hints selected");
        Intent intent = new Intent(this, hints.class);
        startActivity(intent);
    }
    //loads up new activity
    public void guessTheFlag(View view) {
        Log.d(LOG_TAG, "Guess the flag selected");
        Intent intent = new Intent(this, flags.class);
        startActivity(intent);
    }
    //loads up new activity
    public void advancedLevel(View view) {
        Log.d(LOG_TAG, "Advanced level selected");
        Intent intent = new Intent(this, advanced.class);
        startActivity(intent);
    }

    //hashmap links the two arrays of country names and images mapping them as pairs
    public HashMap < String, String > createFlagNamePairs() {
        final HashMap < String, String > hm = new HashMap < > ();
        for (int i = 0; i < 256; i++) {
            hm.put(imageNames[i], countryNames[i]);
        }
        return hm;
    }

//list of images names in an array
   public static String[] getImageNames() {
        String[] imageNames =  {"ad", "ae", "af", "ag", "ai", "al", "am", "an", "ao", "aq", "ar", "as", "at", "au", "aw", "ax", "az", "ba", "bb", "bd", "be",
                "bf", "bg", "bh", "bi", "bj", "bl", "bm", "bn", "bo", "bq", "br", "bs", "bt", "bv", "bw", "by", "bz", "ca", "cc", "cd", "cf", "cg",
                "ch", "ci", "ck", "cl", "cm", "cn", "co", "cr", "cu", "cv", "cw", "cx", "cy", "cz", "de", "dj", "dk", "dm", "dor", "dz", "ec", "ee",
                "eg", "eh", "er", "es", "et", "eu", "fi", "fj", "fk", "fm", "fo", "fr", "ga", "gbeng", "gbnir", "gbsct", "gbwls", "gb", "gd", "ge",
                "gf", "gg", "gh", "gi", "gl", "gm", "gn", "gp", "gq", "gr", "gs", "gt", "gu", "gw", "gy", "hk", "hm", "hn", "hr", "ht", "hu", "id",
                "ie", "il", "im", "in", "io", "iq", "ir", "is", "it", "je", "jm", "jo", "jp", "ke", "kg", "kh", "ki", "km", "kn", "kp", "kr", "kw",
                "ky", "kz", "la", "lb", "lc", "li", "lk", "lr", "ls", "lt", "lu", "lv", "ly", "ma", "mc", "md", "me", "mf", "mg", "mh", "mk", "ml",
                "mm", "mn", "mo", "mp", "mq", "mr", "ms", "mt", "mu", "mv", "mw", "mx", "my", "mz", "na", "nc", "ne", "nf", "ng", "ni", "nl", "no",
                "np", "nr", "nu", "nz", "om", "pa", "pe", "pf", "pg", "ph", "pk", "pl", "pm", "pn", "pr", "ps", "pt", "pw", "py", "qa", "re", "ro",
                "rs", "ru", "rw", "sa", "sb", "sc", "sd", "se", "sg", "sh", "si", "sj", "sk", "sl", "sm", "sn", "so", "sr", "ss", "st", "sv", "sx",
                "sy", "sz", "tc", "td", "tf", "tg", "th", "tj", "tk", "tl", "tm", "tn", "to", "tr", "tt", "tv", "tw", "tz", "ua", "ug", "um", "us",
                "uy", "uz", "va", "vc", "ve", "vg", "vi", "vn", "vu", "wf", "xk", "ws", "ye", "yt", "za", "zm", "zw"};
        return imageNames;
    }

}
