package com.example.flaggame;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import static java.lang.String.valueOf;

public class hints extends AppCompatActivity {

    //number of correct answers
    int correct = 0;

    //timer
    int count = 10;

    //defines drawable images in R class which contains Resource ID's (r.drawables)

    public final static int getResourceId(final String resName, final String resType, final Context ctx) {
        final int ResourceID =
                ctx.getResources().getIdentifier(resName, resType,
                        ctx.getApplicationInfo().packageName);

        return ResourceID;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hints);

        final Random rnd = new Random();
        final ImageView img = findViewById(R.id.hint_image);
        //randomly picks 1 flag from array of images
        final String str = MainActivity.imageNames[rnd.nextInt(256)];
        //uses resource ID to get that random image from the drawable and display it
        img.setImageDrawable(
                getResources().getDrawable(getResourceId(str, "drawable", getApplicationContext()))
        );

        //calls on ID
        final TextView text = findViewById(R.id.character);
        //gives value of ID  country name of the image provided using hashmap
        text.setTextSize(30);
        text.setText(MainActivity.flagNamePairs.get(str));


        final String answer = MainActivity.flagNamePairs.get(str);
        String dash = "";
        //replaces every letter with "_" using a for loop to count each letter
        for (int i = 0; i < answer.length(); i++) {
            dash = dash + "_ ";

        }
        text.setText(dash);
        // displays the name of the country as hashes


        //onClick functions allow the editText to be written and will trigger these responses if the right or wrong character is  entered
        final EditText Enter = findViewById(R.id.tBox);
        final Button hBut = findViewById(R.id.submit_letter);

        hBut.setOnClickListener(new View.OnClickListener() {
            public void onClick(View View) {
                int guess = 0;
                for (int i = 0; i < answer.length(); i++) {
                    if (valueOf(answer.charAt(i)).equals(Enter.getText().toString())) {
                        Enter.setText(Enter.getText().toString());
                        guess = 1;
                        correct += 1;
                    }

                }
            }
        });
        //if the switch was active this code will run where the timer will be added counting down from 10
        if (MainActivity.time == true) {
            final TextView countDown = findViewById(R.id.countDown);
            new CountDownTimer(10_000, 1_000) {
                @Override
                public void onTick(long l) {
                    countDown.setText(String.valueOf(count));
                    count--;
                }
                @Override
                public void onFinish() {
                    //end of timer simulates entering the wrong answer
                    countDown.setText(String.valueOf(0));
                    final TextView correctName = findViewById(R.id.correctName);
                    final TextView hAnswer = findViewById(R.id.hAnswer);
                    hAnswer.setTextColor(Color.RED);
                    hAnswer.setText("WRONG");
                    correctName.setTextColor(Color.BLUE);
                    correctName.setText(MainActivity.flagNamePairs.get(str));
                }
            }.start();
        }

    }
}