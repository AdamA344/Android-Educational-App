package com.example.flaggame;

import android.content.Context;
import android.graphics.Color;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;

public class advanced extends AppCompatActivity {
    //score
    int score = 0;
    //timer
    int count = 10;

    //defines drawable images in R class which contains Resource ID's (r.drawables)
    public final static int getResourceId(final String resName, final String resType, final Context ctx) {
        final int ResourceID =
                ctx.getResources().getIdentifier(resName, resType,
                        ctx.getApplicationInfo().packageName);

        return ResourceID;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced);

        //calls on ID
        final ImageView img1 = findViewById(R.id.flag1);
        final ImageView img2 = findViewById(R.id.flag2);
        final ImageView img3 = findViewById(R.id.flag3);
        final Random rnd = new Random();
        //randomly picks 3 from array of images
        final String str1 = MainActivity.imageNames[rnd.nextInt(256)];
        final String str2 = MainActivity.imageNames[rnd.nextInt(256)];
        final String str3 = MainActivity.imageNames[rnd.nextInt(256)];
        //uses resource ID to get that random image from the drawable and display it
        img1.setImageDrawable(
                getResources().getDrawable(getResourceId(str1, "drawable", getApplicationContext()))
        );
        img2.setImageDrawable(
                getResources().getDrawable(getResourceId(str2, "drawable", getApplicationContext()))
        );
        img3.setImageDrawable(
                getResources().getDrawable(getResourceId(str3, "drawable", getApplicationContext()))
        );

    //call on id's
        final EditText t1 = findViewById(R.id.f1Name);
        final EditText t2 = findViewById(R.id.f2Name);
        final EditText t3 = findViewById(R.id.f3Name);
        final TextView tAns = findViewById(R.id.tAns);
        final TextView Score = findViewById(R.id.Score);

        //onClick functions allow the editText to be written and will trigger these responses if the right or wrong one is  entered
        final Button advBut = findViewById(R.id.button5);
        advBut.setOnClickListener(new View.OnClickListener() {
            public void onClick(View View) {
                if (advBut.getText().equals("Submit")) {
                    String ca = MainActivity.flagNamePairs.get(str1);
                    String ca1 = MainActivity.flagNamePairs.get(str2);
                    String ca2 = MainActivity.flagNamePairs.get(str3);
                    //prevents score from stacking from the same correct answer when pressing submit multiple times
                    score = 0;
                    if (t1.getText().toString().equals(ca)) {
                        score = score + 1;
                        Score.setText("Score: " + score);
                        t1.setTextColor(Color.GREEN);
                        t1.setEnabled(false);
                    } else {
                        t1.setTextColor(Color.RED);

                    }
                    if (t2.getText().toString().equals(ca1)) {
                        score = score + 1;
                        Score.setText("Score: " + score);
                        t2.setTextColor(Color.GREEN);
                        t2.setEnabled(false);
                    } else {
                        t2.setTextColor(Color.RED);

                    }
                    if (t3.getText().toString().equals(ca2)) {
                        score = score + 1;
                        Score.setText("Score: " + score);
                        t3.setTextColor(Color.GREEN);
                        t3.setEnabled(false);
                    } else {
                        t3.setTextColor(Color.RED);

                    }
                    if (t3.getText().toString().equals(ca2) && t2.getText().toString().equals(ca1) && t1.getText().toString().equals(ca)) {
                        advBut.setText("Next");
                        tAns.setText("CORRECT");
                        tAns.setTextColor(Color.GREEN);
                    }
                } else {
                    //refreshes page
                    finish();
                    startActivity(getIntent());
                }
            }
        });
        //if the switch was active this code will run where the timer will be added counting down from 10
        if (MainActivity.time == true) {
            final TextView countDown = findViewById(R.id.countDown);
            new CountDownTimer(10_000, 1_000) {
                @Override
                public void onTick(long l) {
                    countDown.setText(String.valueOf(count));
                    count--;
                }
                @Override
                public void onFinish() {
                    //end of timer simulates entering the wrong answer
                    countDown.setText(String.valueOf(0));
                    t1.setTextColor(Color.RED);
                    t3.setTextColor(Color.RED);
                    t2.setTextColor(Color.RED);
                }
            }.start();
        }
    }
}