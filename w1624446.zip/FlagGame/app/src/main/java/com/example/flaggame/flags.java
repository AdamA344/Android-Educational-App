package com.example.flaggame;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Random;

public class flags extends AppCompatActivity {

    //timer
    int count = 10;

    //defines drawable images in R class which contains Resource ID's (r.drawables)
    public final static int getResourceId(final String resName, final String resType, final Context ctx) {
        final int ResourceID =
                ctx.getResources().getIdentifier(resName, resType,
                        ctx.getApplicationInfo().packageName);

        return ResourceID;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flags);

    //call on ID
        final ImageView img1 = findViewById(R.id.flag1);
        final ImageView img2 = findViewById(R.id.flag2);
        final ImageView img3 = findViewById(R.id.flag3);
        final Random rnd = new Random();
        //randomly picks 3 flags from array of flags
        final String str1 = MainActivity.imageNames[rnd.nextInt(256)];
        final String str2 = MainActivity.imageNames[rnd.nextInt(256)];
        final String str3 = MainActivity.imageNames[rnd.nextInt(256)];

        //uses resource ID to get that random images from the drawable and display it
        img1.setImageDrawable(
                getResources().getDrawable(getResourceId(str1, "drawable", getApplicationContext()))
        );
        img2.setImageDrawable(
                getResources().getDrawable(getResourceId(str2, "drawable", getApplicationContext()))
        );
        img3.setImageDrawable(
                getResources().getDrawable(getResourceId(str3, "drawable", getApplicationContext()))
        );

    //an array of the 3 random images is created, and a random one out of the three is chosen
        String rn[] = {str1, str2, str3};
        final String randomName = rn[rnd.nextInt(3)];
        final TextView cName = findViewById(R.id.cName);
        //hashmap calls on the country name linked to the chosen flag to be displayed
        cName.setText(MainActivity.flagNamePairs.get(randomName));


        final Button button_flag = findViewById(R.id.button_flag);
        button_flag.setOnClickListener(new View.OnClickListener() {
            public void onClick(View View) {
                //refeshes page
                finish();
                startActivity(getIntent());
            }
        });

        //onClick functions allow the image to be clicked and will trigger these responses if the right or wrong one is clicked
        img1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView response = findViewById(R.id.flag_answer);
                if (str1 == randomName) {
                    response.setTextColor(Color.GREEN);
                    response.setText("CORRECT");
                } else {
                    response.setTextColor(Color.RED);
                    response.setText("WRONG");
                }
            }
        });
        img2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView response = findViewById(R.id.flag_answer);
                if (str2 == randomName) {
                    response.setTextColor(Color.GREEN);
                    response.setText("CORRECT");
                } else {
                    response.setTextColor(Color.RED);
                    response.setText("WRONG");
                }
            }
        });
        img3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView response = findViewById(R.id.flag_answer);
                if (str3 == randomName) {
                    response.setTextColor(Color.GREEN);
                    response.setText("CORRECT");
                } else {
                    response.setTextColor(Color.RED);
                    response.setText("WRONG");
                }
            }
        });

        //if the switch was active this code will run where the timer will be added counting down from 10
        if (MainActivity.time == true) {
            final TextView countDown = findViewById(R.id.countDown);
            new CountDownTimer(10_000, 1_000) {
                @Override
                public void onTick(long l) {
                    countDown.setText(String.valueOf(count));
                    count--;
                }
                @Override
                public void onFinish() {
                    //end of timer simulates entering the wrong answer
                    countDown.setText(String.valueOf(0));
                    TextView response = findViewById(R.id.flag_answer);
                    response.setTextColor(Color.RED);
                    response.setText("WRONG");
                }
            }.start();
        }

    }


    public void image1(View view) {}

    public void image2(View view) {}

    public void image3(View view) {}
}